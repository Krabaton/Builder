'use strict';

module.exports = [
  './source/js/app.js'
];